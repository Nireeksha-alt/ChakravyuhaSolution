package Nireeksha;

public class Chakravyuha {

    public static boolean canCrossChakravyuha(int p, int a, int b, int[] enemyPowers) {
        int rechargeValue = p;  
        int skipUsed = 0;
        int rechargeUsed = 0;
        int n = enemyPowers.length;
        
       
        boolean k3Regen = false;
        boolean k7Regen = false;

        for (int i = 0; i < n; i++) {
            if (i == 3 && k3Regen) {  
                p -= enemyPowers[2] / 2;
                if (p <= 0) {
                    return false;
                }
                k3Regen = false;  
            }

            if (i == 7 && k7Regen) {  
                p -= enemyPowers[6] / 2;
                if (p <= 0) {
                    return false;
                }
                k7Regen = false;  
            }

            if (p < enemyPowers[i]) {
                if (skipUsed < a) {
                    skipUsed++;
                    continue;
                } else if (rechargeUsed < b) {
                    rechargeUsed++;
                    p = rechargeValue;
                } else {
                    return false;  
                }
            }

            p -= enemyPowers[i];  
            
            
            if (i == 2 && !k3Regen) {
                k3Regen = true;
            }
            if (i == 6 && !k7Regen) {
                k7Regen = true;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        // Test cases
        int[] enemyPowers1 = {5, 8, 12, 7, 10, 6, 8, 15, 9, 4, 11};
        int p1 = 20;
        int a1 = 2;
        int b1 = 1;

        int[] enemyPowers2 = {3, 5, 10, 6, 8, 12, 4, 7, 14, 5, 9};
        int p2 = 25;
        int a2 = 1;
        int b2 = 2;

        System.out.println("Test Case 1: " + canCrossChakravyuha(p1, a1, b1, enemyPowers1));  
        System.out.println("Test Case 2: " + canCrossChakravyuha(p2, a2, b2, enemyPowers2));  
        int[] enemyPowers3 = {5, 4, 7, 2, 10, 5, 9, 8, 6, 3, 11};
        int p3 = 30;
        int a3 = 2;
        int b3 = 2;

        int[] enemyPowers4 = {3, 3, 5, 4, 8, 7, 6, 5, 10, 8, 12};
        int p4 = 35;
        int a4 = 1;
        int b4 = 3;

        System.out.println("Test Case 3: " + canCrossChakravyuha(p3, a3, b3, enemyPowers3));  
        System.out.println("Test Case 4: " + canCrossChakravyuha(p4, a4, b4, enemyPowers4));  
    }
}